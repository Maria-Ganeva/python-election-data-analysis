'''
  demo.py
	Authors of the current version: Lidiachanel Alvarado Dubkova (1360452), Maria Ganeva (1373383), Matthew Chu (1384202)

    Project: 307 - Lima: Team Project - Milestone III
    Date of Last Update: Mar 23, 2026.

    Functional Summary
        This program analyzes Canadian federal election data and generates a bar chart of
        valid votes by political party for a selected province and election year. 
        Depending on the selected option, it either compares election results with the 
        percentage of young adults (ages 20–29) in the population or with the residential
        property price index. The program reads data from CSV files and visualizes the 
        results using matplotlib.

       Commandline Parameters: 3
        argv[1] = Election year identifier (43 for 2019 or 44 for 2021)
        argv[2] = Province/territory code (e.g., ON, QC, BC, etc.)
        argv[3] = Analysis type (1 for votes vs. youth population, 2 for votes vs. 
            residential property price index)
'''

import datetime
import sys

# pandas is a library for working with structured data such as CSV files. 
# We will use it here to identify data by column
import pandas as pd

# seaborn and matplotlib are for plotting.  The matplotlib
# library is the actual graphics library, and seaborn provides
# a nice interface to produce plots more easily.
import seaborn as sns
from matplotlib import pyplot as plt

# Calculate the average price index for a given row and year using quarterly values.
#
# This function retrieves the Q1, Q2, Q3, and Q4 values for the specified year and row,
#   from the provided DataFrame and returns their arithmetic average.
#
# Args:
#   row (int): The row index in the DataFrame corresponding to the target record.
#   year (str): The year (e.g., "2023") used to construct column names (e.g., "Q1 2023").
#   price_index_df (pandas.DataFrame): DataFrame containing quarterly price index values,
#       with columns formatted as "Q1 <year>", "Q2 <year>", etc.
#
# Returns:
#   float: The average of the four quarterly price index values.
#
# Raises:
#   KeyError: If expected quarterly columns are missing.
#   ValueError: If values cannot be converted to float.
    
def calculate_quarter_average(row: int, year: str, price_index_df) -> float:
    price_index_value_q1 = float(price_index_df.at[row, "Q1 " + year])
    price_index_value_q2 = float(price_index_df.at[row, "Q2 " + year])
    price_index_value_q3 = float(price_index_df.at[row, "Q3 " + year])
    price_index_value_q4 = float(price_index_df.at[row, "Q4 " + year])

    price_index_value = (price_index_value_q1 + price_index_value_q2 + price_index_value_q3 + price_index_value_q4) / 4

    return price_index_value

# Main entry point for the program.
#
# Parses command-line arguments, validates inputs, and generates
#   visualizations based on the selected question:
#       1 → Votes vs. youth population percentage
#       2 → Votes vs. residential property price index

def main(argv):

    #
    #   Check that we have been given the right number of parameters,
    #   and store the single command line argument in a variable with
    #   a better name
    #
    if len(argv) != 4:
        print("Usage:",
                "demo.py <election 43 or 44> <province code> <question 1 or 2>")
        sys.exit(-1)

    election = argv[1]
    province = argv[2]
    question = argv[3]

    # election = "44"
    # province = "ON"
    # question = "1"

    # Validate command-line arguments
    if election not in ["43", "44"]:
        print("Error: election parameter must be '43' or '44'", file=sys.stderr)
        sys.exit(-1)
    if province not in ["NL", "PE", "NS", "NB", "QC", "ON", "MB", "SK", "AB", "BC", "YT", "NT", "NU"]:
        print("Error: province parameter must be a valid province code", file=sys.stderr)
        sys.exit(-1)    
    if question not in ["1", "2"]:
        print("Error: question parameter must be '1' or '2'", file=sys.stderr)
        sys.exit(-1)

    # Define column mapping for each province
    province_columns = {
        "NL": "N.L. Valid Votes/Votes valides T.-N.-L.",
        "PE": "P.E.I. Valid Votes/Votes valides I.-P.-E.",
        "NS": "N.S. Valid Votes/Votes valides N.-E.",
        "NB": "N.B. Valid Votes/Votes valides N.-B.",
        "QC": "Que. Valid Votes/Votes valides Qc",
        "ON": "Ont. Valid Votes/Votes valides Ont.",
        "MB": "Man. Valid Votes/Votes valides Man.",
        "SK": "Sask. Valid Votes/Votes valides Sask.",
        "AB": "Alta. Valid Votes/Votes valides Alb.",
        "BC": "B.C. Valid Votes/Votes valides C.-B.",
        "YT": "Y.T. Valid Votes/Votes valides Yn",
        "NT": "N.W.T. Valid Votes/Votes valides T.N.-O.",
        "NU": "Nun. Valid Votes/Votes valides Nt"
    }
    
    province_names = {
        "NL": "newfoundland_and_labrador",
        "PE": "prince_edward_island",
        "NS": "nova_scotia",
        "NB": "new_brunswick",
        "QC": "quebec",
        "ON": "ontario",
        "MB": "manitoba",
        "SK": "saskatchewan",
        "AB": "alberta",
        "BC": "british_columbia",
        "YT": "yukon",
        "NT": "northwest_territories",
        "NU": "nunavut"
    }

    year_columns = {
        "43": "2019", #election Quarter
        "44": "2021"
    }

    csv_filename = "data/" + election + "_general_election.csv"
    try:
        votes_df = pd.read_csv(csv_filename, usecols=["Political affiliation/Appartenance politique",province_columns[province]])
    except IOError as err:
        print("Unable to open source file", csv_filename, ": {}".format(err), file=sys.stderr)
        sys.exit(-1)

    # Extract English party names (before '/') from bilingual column
    votes_df['Party Names'] = votes_df['Political affiliation/Appartenance politique'].str.split('/').str.get(0)

    if question == "1":

        csv_filename = "data/population_" + province_names[province] + ".csv"
        try:
            # Skip non-data rows so only rows 12–33 (actual population data) are read
            # 10000 is used as an upper bound to ensure all trailing rows are skipped
            skip = list(range(0, 10)) + [11] + list(range(34, 10000))
            population_df = pd.read_csv(csv_filename, skiprows=skip)
        except IOError as err:
            print("Unable to open source file", csv_filename, ": {}".format(err), file=sys.stderr)
            sys.exit(-1)

        # Rows 5 and 6 in the filtered dataset correspond to age groups 20–24 and 25–29
        years_20_24_value = int(population_df.at[5, year_columns[election]].replace(",", ""))
        years_25_29_value = int(population_df.at[6, year_columns[election]].replace(",", ""))
        all_ages_value = int(population_df.at[0, year_columns[election]].replace(",", ""))

        young_adult_percentage = f"{(years_20_24_value + years_25_29_value) / all_ages_value * 100:.2f}"
        votes_df["Young adults (20-29 years) %"] = young_adult_percentage

        fig = plt.figure(figsize=(12,8))

        parties = votes_df["Party Names"]
        votes = votes_df[province_columns[province]]

        plt.bar(parties, votes)

        plt.xlabel("Party Names", fontweight='bold', fontsize=15)
        plt.ylabel("NUMBER OF VOTES", fontweight='bold', fontsize=15)
        plt.text(0.5, 1.07, f"Percentage of young adults: {young_adult_percentage}%", transform=plt.gca().transAxes, fontsize=12, ha='center')
        #plt.title("Votes vs. Youth Population")
        
        plt.xticks(rotation=45, ha='right')

        fig.savefig("young_adults_"+ province + "_" + election + "_" + datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".png", bbox_inches="tight")

        # Display the plot
        plt.show()

    elif question == "2":
        if province not in ["QC", "ON", "AB", "BC"]:
            print("Province {} not available. Select one of: QC, ON, AB, BC".format(province), file=sys.stderr)
            sys.exit(-1)

        csv_filename = "data/residential_property_price_index.csv"
        try:
            price_index_df = pd.read_csv(csv_filename)
        except IOError as err:
            print("Unable to open source file", csv_filename,
                    ": {}".format(err), file=sys.stderr)
            sys.exit(-1)

        if province == "QC":
            price_index_value = calculate_quarter_average(1, year_columns[election], price_index_df)
        elif province == "ON":
            price_index_value_1 = calculate_quarter_average(2, year_columns[election], price_index_df)
            price_index_value_2 = calculate_quarter_average(3, year_columns[election], price_index_df)

            price_index_value = (price_index_value_1 + price_index_value_2) / 2
        elif province == "AB":
            price_index_value = calculate_quarter_average(4, year_columns[election], price_index_df)
        else:
            price_index_value_1 = calculate_quarter_average(5, year_columns[election], price_index_df)
            price_index_value_2 = calculate_quarter_average(6, year_columns[election], price_index_df)

            price_index_value = (price_index_value_1 + price_index_value_2) / 2

        votes_df["Residential Property Price Index"] = price_index_value

        fig = plt.figure(figsize=(12,8))

        parties = votes_df["Party Names"]
        votes = votes_df[province_columns[province]]

        plt.bar(parties, votes)

        plt.xlabel("Party Names", fontweight='bold', fontsize=15)
        plt.ylabel("NUMBER OF VOTES", fontweight='bold', fontsize=15)
        plt.text(0.5, 1.07, f"Residential Property Price Index: {price_index_value:.2f}", transform=plt.gca().transAxes, fontsize=12, ha='center')
        
        plt.xticks(rotation=45, ha='right')

        fig.savefig("property_price_"+ province + "_" + election + "_" + datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".png", bbox_inches="tight")

        plt.show()
 
main(sys.argv)